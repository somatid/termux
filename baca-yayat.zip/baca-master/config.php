<?php


$uid="Facebook_10213883669147720";
$raw_uid="4613138b-98c0-4e06-9047-6fd7433a3543";
$user_name="Moch+Hayatullah";
$invite_code="Fkml9Hf8Tw";
$own_mac="18%3A00%3A2d%3Af4%3Ad5%3A43";
$android_id="e0afbe6d3cc6d0bd";
$device_type="Sony++C6603";


?>